package b_slides;

import java.util.Date;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class RecordImmutabilityExample
{
    public static void main(String[] args)  
    {
		record DateRange(Date start, Date end) {}
		
		DateRange range1 = new DateRange(new Date(71,1,7), new Date(71,2,27));
		System.out.println(range1);
		
		DateRange range2 = new DateRange(new Date(71,6,7), new Date(71,2,27));
		System.out.println(range2);
    }
}
