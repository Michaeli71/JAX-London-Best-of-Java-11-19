package b_slides;

import java.time.Duration;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class DurationJdk9Example2 
{
	public static void main(String[] args) 
	{
		final Duration tenDaysSevenHoursThirdMinutes = Duration.ofDays(10).plusHours(7).plusMinutes(30);

		// JDK 9:toXXX() und toXXXPart()
		System.out.println("toDays():        " + tenDaysSevenHoursThirdMinutes.toDays());
		System.out.println("toDaysPart():    " + tenDaysSevenHoursThirdMinutes.toDaysPart());
		System.out.println("toHours():       " + tenDaysSevenHoursThirdMinutes.toHours());
		System.out.println("toHoursPart():   " + tenDaysSevenHoursThirdMinutes.toHoursPart());
		System.out.println("toMinutes():     " + tenDaysSevenHoursThirdMinutes.toMinutes());
		System.out.println("toMinutesPart(): " + tenDaysSevenHoursThirdMinutes.toMinutesPart());
	}
}