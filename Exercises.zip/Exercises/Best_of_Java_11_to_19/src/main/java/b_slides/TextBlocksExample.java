package b_slides;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class TextBlocksExample {

	public static void main(String[] args) {

		String jsonObj = """
						{
						    "name": "Mike",
					        "birthday": "1971-02-07",
						    "comment": "Text blocks are nice!"
						}
				     """;

		System.out.println(jsonObj);
		
		String text = """
				      This is a string splitted in several smaller \
				      jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj \
				      jjjjjjjjjjjjjjjjjjjjjjjj \
				      jjjjjjjjjjjj strings""";    

		System.out.println(text);
		System.out.println(text.getClass());
	}
}
