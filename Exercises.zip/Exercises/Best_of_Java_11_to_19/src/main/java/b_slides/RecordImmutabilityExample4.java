package b_slides;

import java.time.LocalDate;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class RecordImmutabilityExample4
{
    public static void main(String[] args)  
    {
		record DateRange(LocalDate start, LocalDate end) 
		{
			DateRange
			{
				if (!start.isBefore(end))
					throw new IllegalArgumentException("start >= end");
			}
		}
				
		DateRange range1 = new DateRange(LocalDate.of(1971,1,7), LocalDate.of(1971,2,27));
		System.out.println(range1);
		
		DateRange range2 = new DateRange(LocalDate.of(1971,6,7), LocalDate.of(1971,2,27));
		System.out.println(range2);
    }
}
