package solutions.part1;

import java.util.function.Function;
import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise07a_Strings 
{
	public static void main(String[] args) 
	{
		Function<Integer, String> mapper = num -> ("" + num).repeat(num);
		
		Stream.of(2,4,7,3,1,9,5).map(mapper).
		                         forEach(System.out::println);
		
        var coffeePot = """ 
                        _.._..,_,_
                        (          )
                         ]~,"-.-~~[
                       .=])' (;  ([
                       | ]:: '    [
                       '=]): .)  ([
                         |:: '    |
                          ~~----~~""";
        System.out.println(coffeePot);
        
	}	
}