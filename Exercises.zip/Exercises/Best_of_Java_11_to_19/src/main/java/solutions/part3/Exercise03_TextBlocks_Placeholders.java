package solutions.part3;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise03_TextBlocks_Placeholders 
{
	public static void main(final String[] args) 
	{
		String multiLineStringWithPlaceHoldersOld = String.format("HELLO \"%s\"!\n" +
				 "  HAVE %s\n" +
				 "  NICE \"%s\"!",
				 "WORLD", "A", "DAY");
		System.out.println(multiLineStringWithPlaceHoldersOld);

		String multiLineStringWithPlaceHolders = """
			HELLO "%s"!
  			  HAVE %s
      	      NICE "%s"!
            """.formatted("WORLD", "A", "DAY");
        System.out.println(multiLineStringWithPlaceHolders);
	}
}
