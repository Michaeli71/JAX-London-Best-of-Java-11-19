package solutions.part2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise05_Reader 
{
	public static void main(String[] args) throws IOException 
	{
		var textFile = new File("hello.txt");
		var sr = new StringReader("Hello\nWorld");
				
		try (var bfw = new BufferedWriter(new FileWriter(textFile)))
		{
			sr.transferTo(bfw);
		}

		var sw = new StringWriter();
		try (var bfr = new BufferedReader(new FileReader(textFile)))			
		{
			bfr.transferTo(sw);
		}
		System.out.println(sw.toString());
	}
}