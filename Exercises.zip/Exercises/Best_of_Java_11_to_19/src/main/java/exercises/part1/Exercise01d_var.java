package exercises.part1;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise01d_var 
{
	public static void main(String[] args) 
	{
		// var isEven = n -> n % 2 == 0;
		// var isEmpty = String::isEmpty;
	}
}
