package exercises.part1;

import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise03_StreamExample 
{	
	public static void main(String[] args) 
	{
		final Stream<String> values1 = Stream.of("a", "b", "c", "", "e", "f"); 
		final Stream<Integer> values2 = Stream.of(1, 2, 3, 11, 22, 33, 7, 10);

		// TODO
	}
}
