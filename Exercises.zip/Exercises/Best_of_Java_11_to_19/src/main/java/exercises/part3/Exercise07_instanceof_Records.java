package exercises.part3;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise07_instanceof_Records 
{
	record Square(double sideLength) {
	}
	
	record Circle(double radius) {
	}
	
	public double computeAreaOld(final Object figure) 
	{
		if (figure instanceof Square) 
		{
			final Square square = (Square) figure;
			return square.sideLength * square.sideLength;
		} 
		else if (figure instanceof Circle) 
		{
			final Circle circle = (Circle) figure;
			return circle.radius * circle.radius * Math.PI;
		}
		throw new IllegalArgumentException("figure is not a recognized figure");
	}

}
