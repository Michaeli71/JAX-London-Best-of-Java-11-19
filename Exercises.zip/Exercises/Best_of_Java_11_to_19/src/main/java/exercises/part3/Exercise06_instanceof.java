package exercises.part3;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise06_instanceof 
{
	public static void main(String[] args) 
	{	
		Object obj ="BITTE ein BIT";
		
		if (obj instanceof String) 
		{
			final String str = (String)obj; 
			if (str.contains("BITTE"))
			{
		         System.out.println("It contains the magic word!");
		    }
		}
	}
}
