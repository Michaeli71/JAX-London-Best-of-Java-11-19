package exercises.part2;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise04_InpuStreamReadBytesExample 
{
	public static void main(final String[] args) throws IOException
	{
	    final byte[] buffer = { 72, 65, 76, 76, 79 };

	    final byte[] resultJdk8 = readAllBytesJdk8(/* TODO */ null);
	    System.out.println(Arrays.toString(resultJdk8));

	    transferToJdk8(/* TODO */ null, System.out);
	}

	private static byte[] readAllBytesJdk8(final InputStream is) throws IOException
	{
	    try (final ByteArrayOutputStream os = new ByteArrayOutputStream())
	    {
	        transferToJdk8(is, os);
	        os.flush();

	        return os.toByteArray();
	    }
	}

	private static void transferToJdk8(final InputStream in, 
	                                   final OutputStream out) throws IOException
	{
	    final byte[] buffer = new byte[1024];
	    int len;
	    while ((len = in.read(buffer)) != -1)
	    {
	        out.write(buffer, 0, len);
	    }
	}
}
