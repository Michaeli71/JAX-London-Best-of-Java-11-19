package exercises.part2;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise05_Reader 
{
	public static void main(String[] args) throws IOException 
	{
		var textFile = new File("hello.txt");
		var sr = new StringReader("Hello\nWorld");
				
		try (Writer bfw = null /*TODO*/)
		{
			// TODO
		}

		var sw = new StringWriter();
		try (Reader bfr = null /*TODO*/)			
		{
			// TODO
		}
		System.out.println(sw.toString());
	}
}