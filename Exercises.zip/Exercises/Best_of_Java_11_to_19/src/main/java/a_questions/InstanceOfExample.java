package a_questions;


/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class InstanceOfExample {

	public static void main(String[] args) {
		
	    Object obj2 = "BACSGsJAHG";
	    
        if (obj2 instanceof String) 
        {
            String str2 = (String)obj2;
            if (str2.length() > 5 && str2.startsWith("BA"))
            {
                System.out.println("Länge: " + str2.length());                
            }
        }
        
	    if (obj2 instanceof String str2 && str2.length() > 5 && str2.startsWith("BA"))
	    {
	        System.out.println("Länge: " + str2.length());
	    }
	}
}
