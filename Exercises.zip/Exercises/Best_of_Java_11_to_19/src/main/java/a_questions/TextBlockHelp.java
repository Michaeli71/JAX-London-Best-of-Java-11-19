package a_questions;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class TextBlockHelp {

    public static void main(String[] args) {
        String multiLineStringOld = """
            THIS IS
            A MULTI
            LINE STRING
            WITH A BACKSLASH \\
            """;
        System.out.println(multiLineStringOld);
    }

}
