package a_questions;

import java.util.function.Predicate;
import java.util.stream.Collector;

/**
 * Beispielprogramm für den Workshop "Best of Java 11 bis 19" / 
 * das Buch "Java – die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *
 *         Copyright 2021/2022 by Michael Inden
 */
public class Exercise9_CollectorsUtils 
{
	public static <T, A, R> Collector<T, A, R> filtering(final Predicate<? super T> filter, 
			                                             final Collector<T, A, R> collector) 
	{
		  return Collector.of(
		      collector.supplier(),
		      
		      // TRICK
		      (accumulator, input) -> {
		         if (filter.test(input)) {
		            collector.accumulator().accept(accumulator, input);
		         }
		      },		      
		      
		      collector.combiner(),
		      collector.finisher());
	}
}
